# SKitLs-WeatherBot
Simple telegram bot, written in C# and powered by [SKitLs.Bots.Telegram](https://github.com/Sargeras02/SKitLs.Bots.Telegram.git) solution.

Refered to [a habr article](https://habr.com/ru/sandbox/196742/).
